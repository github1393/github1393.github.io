__author__ = 'GOD'

import tornado
from models import *


class ShowHandler(tornado.web.RequestHandler):
    def get(self):
        catInfo = Post.select().order_by(Post.id.desc())
        self.render('show.html', catInfo=catInfo)


class AddHandler(tornado.web.RequestHandler):
    def get(self):
        self.render('add.html')

    def post(self, *args):
        title = self.get_argument("title")
        text = self.get_argument("text")

        catInfo = Post.create(
            title=title,
            text=text
        )


        self.redirect('/')


class DeleteHandler(tornado.web.RequestHandler):
    def get(self, *args):
        catId = args[0]
        catInfo = Post.select().where(Post.id == catId).get().delete_instance()

        self.redirect('/')


class EditHandler(tornado.web.RequestHandler):
    def get(self, *args):
        catId = args[0]
        catInfo = Post.select().where(Post.id == catId).get()

        self.render('edit.html', catInfo=catInfo)


    def post(self, *args):
        catId = args[0]
        catInfo = Post.select().where(Post.id == catId).get()

        catInfo.title = self.get_argument("title")
        catInfo.text = self.get_argument("text")

        catInfo.save()

        self.redirect('/')


class loginuser(tornado.web.RequestHandler):
    def get(self):
        login1=login.select()
        self.render('login/index.html', login1=login1)

