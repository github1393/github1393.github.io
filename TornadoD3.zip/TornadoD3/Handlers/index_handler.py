import tornado
from models import Post
__author__ = 'mojtaba.banaie'


class IndexHandler(tornado.web.RequestHandler):
    def get(self):
        catInfo = Post.select().order_by(Post.id.desc())
        self.render('index.html',UN= "Hello!", catInfo=catInfo)
        # else :
        #     session.set('LoggedIn', {"_id":"12222222","name":"ali"})
        #     self.render('index.html',UN="U Are Not Logged In..")
