__author__ = 'mojtaba.banaie'
from Handlers.index_handler import IndexHandler
from Handlers.category__handler import CategoryHandler,CategoryEditHandler,CategoryDeleteHandler,CategoryNewHandler
from Handlers.post_handler import ShowHandler,AddHandler,DeleteHandler,EditHandler,loginuser
urlList  = [
    (r'/', IndexHandler),
    # (r'/category$', CategoryHandler),
    # (r'/category/edit/(\d+)$', CategoryEditHandler),
    # (r'/category/delete/(\d+)$', CategoryDeleteHandler),
    # (r'/category/new$', CategoryNewHandler),
    (r'/show$', ShowHandler),
    (r'/add$', AddHandler),
    (r'/delete/(\d+)', DeleteHandler),
    (r'/edit/(\d+)', EditHandler),
    (r'/login$', loginuser)
]